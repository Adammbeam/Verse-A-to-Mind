// The two functions the extension runs inside a tab, and only after you point Verse at it (Alt+Shift+V or the right-click menu).
// Each runs alone in the page (chrome.scripting.executeScript copies the function, not this file), so neither uses anything outside itself.

// B1: what Verse may see of the tab: its title, address, the text you selected, and which box you were typing in. Nothing else of the page.
function voidReadTab() {
  const el = document.activeElement;
  const fieldOf = (e) => {
    if (!e || e === document.body || e === document.documentElement) return null;
    const tag = e.tagName.toLowerCase();
    const textInput = tag === 'input' && /^(?:text|search|email|url|tel|)$/.test((e.getAttribute('type') || '').toLowerCase());
    if (!(tag === 'textarea' || textInput || e.isContentEditable)) return null;
    const name = e.getAttribute('aria-label') || e.getAttribute('placeholder') || e.getAttribute('name') || e.id || '';
    return { tag: e.isContentEditable ? 'editable' : tag, name: String(name).slice(0, 80) };
  };
  let selection = '';
  if (el && typeof el.selectionStart === 'number' && typeof el.value === 'string' && el.selectionEnd > el.selectionStart) selection = el.value.slice(el.selectionStart, el.selectionEnd);
  else selection = String(window.getSelection ? window.getSelection() : '');
  const field = fieldOf(el);
  // remembered in the extension's own world in this page (pages can't see it), so a draft goes to the box you were in
  window.__voidField = field ? el : null;
  // the context check (lib/context-check.js): what kind of page this mostly is, as counts only (characters of text, large pictures
  // on screen, table rows and cells); Verse decides text / image / table from these and the tab card suggests one skill
  let content = null;
  try {
    const shown = (e) => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
    content = { text: (document.body && document.body.innerText || '').replace(/\s+/g, ' ').trim().length,
      images: [...document.images].filter((i) => i.naturalWidth >= 200 && i.naturalHeight >= 200 && shown(i)).length,
      rows: document.querySelectorAll('table tr').length, cells: document.querySelectorAll('table td, table th').length };
  } catch (_) {}
  return { title: document.title.slice(0, 200), url: location.href.slice(0, 500), selection: selection.trim().slice(0, 5000), field, content };
}

// "draft for me: proposal" (sends it to Verse): the text of the thread you are reading, once, when you press it. Gmail keeps the
// open thread in its main region; any other page gives its body. The box you are writing in is left out (that is your reply).
function voidReadThread() {
  const root = document.querySelector('[role="main"]') || document.body;
  if (!root) return { ok: false, why: 'no-text' };
  const mine = window.__voidField && root.contains(window.__voidField) ? window.__voidField : null;
  let text = root.innerText || '';
  if (mine) { const typed = mine.value != null ? mine.value : mine.innerText || ''; if (typed) text = text.replace(typed, ''); }
  text = text.replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim().slice(0, 8000);
  return text ? { ok: true, text } : { ok: false, why: 'no-text' };
}

// B2: put Verse's draft into the box you were typing in, the way typing would. It never presses send, submits a form or clicks anything.
function voidPutDraft(text) {
  const live = (e) => e && e.isConnected && (e.isContentEditable || (/^(?:textarea|input)$/i.test(e.tagName) && !e.disabled && !e.readOnly));
  const el = live(document.activeElement) ? document.activeElement : live(window.__voidField) ? window.__voidField : null;
  if (!el) return { ok: false, why: 'no-field' };
  el.focus();
  let done = false;
  try { done = document.execCommand('insertText', false, String(text)); } catch (_) {}
  if (!done || (!el.isContentEditable && !String(el.value).includes(String(text)))) {
    if (el.isContentEditable) el.textContent += String(text);
    else {
      const s = el.selectionStart ?? el.value.length, e = el.selectionEnd ?? el.value.length;
      el.value = el.value.slice(0, s) + String(text) + el.value.slice(e);
    }
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: String(text) }));
  }
  return { ok: true, field: el.isContentEditable ? 'editable' : el.tagName.toLowerCase() };
}

// B3: one step you said yes to, on a site you allowed: fill a field with text, or click a button, each named by its visible
// label. It never submits a form or presses Enter: a field is filled the way typing would fill it, and a button that would
// submit its form is refused (you press it yourself), and so is a button that deletes something or moves money (Delete, Pay,
// Transfer, in a few languages). Two elements matching the label is a refusal too: it acts on one thing.
function voidAct(step) {
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  // defined in here, not at the top: executeScript sends only this function's own source to the page
  const RISKY = new RegExp('(?<!\\p{L})(?:' + [
    'delete', 'remove', 'erase', 'discard', 'destroy', 'wipe', 'trash', 'empty trash', 'unsubscribe', 'cancel subscription', 'deactivate', 'close account',
    'pay', 'payment', 'pay now', 'purchase', 'buy', 'buy now', 'checkout', 'check out', 'place order', 'order now', 'complete order', 'submit order',
    'transfer', 'send money', 'send payment', 'withdraw', 'donate',
    'supprimer', 'effacer', 'payer', 'acheter', 'commander', 'virement', 'transférer', // French
    'löschen', 'entfernen', 'bezahlen', 'zahlen', 'kaufen', 'bestellen', 'überweisen', // German
    'eliminar', 'borrar', 'pagar', 'comprar', 'transferir', // Spanish, Portuguese
    'elimina', 'cancella', 'paga', 'acquista', 'compra', 'excluir', 'apagar', // Italian, Portuguese
    'verwijderen', 'betalen', 'kopen', // Dutch
  ].join('|') + ')(?!\\p{L})', 'iu');
  const want = norm(step && step.label);
  if (!want || !step || (step.action !== 'fill' && step.action !== 'click')) return { ok: false, why: 'bad-step' };
  const shown = (e) => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length) && getComputedStyle(e).visibility !== 'hidden';
  const labelOf = (e) => {
    const names = [e.getAttribute('aria-label'), e.getAttribute('placeholder'), e.getAttribute('title'), e.getAttribute('name'), e.id]; // the id last: voidReadTab names a box by it when nothing else does
    if (e.id) { const l = document.querySelector('label[for="' + CSS.escape(e.id) + '"]'); if (l) names.push(l.textContent); }
    const wrap = e.closest('label'); if (wrap) names.push(wrap.textContent);
    if (step.action === 'click') names.push(e.textContent, e.value);
    return names.map(norm).filter(Boolean);
  };
  const pool = step.action === 'fill'
    ? [...document.querySelectorAll('textarea, input, [contenteditable=""], [contenteditable="true"]')].filter((e) => e.isContentEditable || e.tagName === 'TEXTAREA' || /^(?:text|search|email|url|tel|)$/i.test(e.getAttribute('type') || ''))
    : [...document.querySelectorAll('button, [role="button"], input[type="button"]')];
  const usable = pool.filter((e) => shown(e) && !e.disabled && !e.readOnly);
  // "the box you were in" (box: 'mine', a reply or a proposal Verse drafted for that box): first the very box you were typing in
  // when you pointed Verse at the page, if it is still there; mail apps re-draw their compose box, so then the compose box by its
  // shape: a multi-line box you can type in (a textarea, a contenteditable, role=textbox), never a search box, never a one-line
  // field like To or Subject. Its label is only a hint (it differs by language and by mail app): it breaks a tie between two.
  let el = null;
  if (step.action === 'fill' && step.box === 'mine') {
    const mine = window.__voidField;
    if (mine && mine.isConnected && shown(mine) && !mine.disabled && !mine.readOnly) el = mine;
    else {
      const searchy = (e) => e.getAttribute('role') === 'searchbox' || !!e.closest('[role="search"], form[role="search"], search') || /\b(?:search|suche|recherche|rechercher|buscar|cerca|zoeken)\b/i.test(e.getAttribute('aria-label') || e.getAttribute('placeholder') || '');
      const boxes = [...document.querySelectorAll('textarea, [contenteditable=""], [contenteditable="true"], [role="textbox"]')]
        .filter((e) => (e.tagName === 'TEXTAREA' || e.isContentEditable) && usable.includes(e) && !searchy(e) && !(e.parentElement && e.parentElement.closest('[contenteditable=""], [contenteditable="true"]')));
      const area = (e) => { const r = e.getBoundingClientRect(); return r.width * Math.max(r.height, 1); };
      const named = boxes.filter((e) => labelOf(e).includes(want));
      if (boxes.length === 1) el = boxes[0];
      else if (named.length === 1) el = named[0];
      else if (boxes.length > 1) { const big = boxes.slice().sort((a, b) => area(b) - area(a)); if (area(big[0]) >= 2 * area(big[1])) el = big[0]; else return { ok: false, why: 'ambiguous', count: boxes.length }; }
      else return { ok: false, why: 'not-found' };
    }
  }
  if (!el) {
    let hits = usable.filter((e) => labelOf(e).includes(want));
    if (!hits.length) hits = usable.filter((e) => labelOf(e).some((n) => n.includes(want)));
    if (!hits.length) return { ok: false, why: 'not-found' };
    if (hits.length > 1) return { ok: false, why: 'ambiguous', count: hits.length };
    el = hits[0];
  }
  if (step.action === 'click') {
    // a button that deletes something or moves money is refused too, whatever label it was asked by: many apps delete or pay
    // with a plain button, no form to submit. Every name it has counts (its text, aria-label, title, id), in a few languages.
    if (labelOf(el).some((n) => RISKY.test(n))) return { ok: false, why: 'destructive' };
    const submits = el.tagName === 'BUTTON' ? (el.getAttribute('type') || 'submit').toLowerCase() === 'submit' && !!el.form : false;
    if (submits) return { ok: false, why: 'submits' };
    el.click();
    return { ok: true, did: 'clicked' };
  }
  const text = String(step.text == null ? '' : step.text).slice(0, 20000);
  el.focus();
  // typing's own path first (it fires the input events a page listens for); setting the value is the fallback, with the event typing would send
  if (el.isContentEditable) { const r = document.createRange(); r.selectNodeContents(el); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); }
  else if (el.select) el.select();
  let typed = false; try { typed = document.execCommand('insertText', false, text); } catch (_) {}
  // a rich box (Gmail, Outlook) turns line breaks into its own blocks: what it typed counts when the words match, so the page's own
  // formatting is kept rather than flattened
  const now = () => (el.isContentEditable ? el.innerText : el.value), same = (a, b) => String(a).replace(/\s+/g, ' ').trim() === String(b).replace(/\s+/g, ' ').trim();
  if (!typed || !same(now(), text)) {
    if (el.isContentEditable) el.textContent = text; else el.value = text;
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
  }
  el.dispatchEvent(new Event('change', { bubbles: true }));
  return { ok: true, did: 'filled' };
}
