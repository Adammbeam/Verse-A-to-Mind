# Verse extension (Chrome / Edge)

Verse in the browser's side panel. It works with the page you are on in two ways, and each one says which it is.

**In your browser only (B1, B2).** Nothing leaves the browser.
- **Alt+Shift+V** on any page, or right-click "Verse: read this tab (stays in your browser)": opens the panel and reads that tab into a card: its title, address, the text you selected, and the box you were typing in.
- Right-click "Verse: count words on this page (stays in your browser)": a small badge on the page shows the words and characters in your selection, or in the whole page when nothing is selected. The count runs in the page, is never sent anywhere and disappears after 20 seconds (or when you close it). It uses the same word rule as /word-count/.
- The card's "put in the page", and "into the page" under an answer, type the text into the box you were in, the way typing would. It never presses send, submits a form or clicks anything; you do that yourself.
- The card lives in memory only. It is never saved with the stage (which syncs to `/api/mine` when you're signed in), and no ask, log or lookup carries it. Close the panel and it is gone.

**Sent to Verse for one answer.** The menu items say "(sends it to Verse)".
- Right-click on a page, "Ask Verse about this page": Verse answers about the page you are on.
- Right-click in a text field (a Gmail draft, a doc, a comment box), "Help me with this draft": Verse rewrites it, ready to paste.
- These read the title, the address, your selection, the text field you are in and up to 8,000 characters of visible text, and send them to Verse's answer engine (`/api/answer`, field `page`), never in the address bar.
- Secrets in the page (keys, tokens, passwords in links) are masked before the model sees them, and nothing about the page is stored. Password fields are never read.
- The answer card says "this page was sent to a-to-mind.com for this answer".
- On the tab card (after Alt+Shift+V), "draft for me: reply · summary · notes · rewrite (sends it to Verse)": the title, address and selected text go to Verse's answer engine once (`/api/answer`, `mode: 'draft'`, `void-live-deploy/lib/draft.js`; the address kept to host and path, keys masked, nothing stored), and the draft comes back into the card's box, ready for "put in the page" or copy. Whatever is in the box goes along as a note to Verse. The card then says what was sent and for what. With no model, a plain rules draft comes back instead of nothing.

**Acts for you (B3).** One step at a time, on a site you allowed, after your yes.
- In the tab card, write a step for Verse: "fill Reply with Thanks, see you Friday" or "click Save". Verse proposes it; it does nothing itself.
- The panel (the extension, not the page in its frame) shows the step as a card: the site, the field or button by its visible label, and the text. Nothing happens until you press Yes there.
- It acts only on a site on your list, "sites Verse may act on" at the bottom of the panel. The list is empty until you add a site, lives in the extension's own storage, and only you edit it there; the page in the frame can't. A site not on the list gets no card at all.
- A step never submits a form or presses Enter. A field is filled the way typing would fill it; a button that would send its form is refused, and you press it yourself. So is a button that deletes something or moves money, form or not: Delete, Remove, Pay, Buy, Checkout, Transfer and the like, in English, French, German, Spanish, Italian, Portuguese and Dutch, by any of its names (its text, aria-label, title or id), even when you asked for it by another one. Two things with the same label is a refusal too.
- Verse proposes the step itself after a "draft for me: reply": on a site on your list, the reply comes back as the same card, "fill <the box you were in> with <the draft>", with the same Yes / No and the same record. Off the list the draft stays copy-only, as before, and nothing is said about acting.
- A short run: two or three steps in one ask, split by ";" or "then" ("fill Reply with Thanks, see you Friday; click Save"). The panel shows them as one card listing every step and asks Yes / No for each in turn. It stops at the first No or the first step the page refuses (a missing label, two of the same, a button that sends its form), and nothing after that runs. Same allow list, and each step leaves its own record. Four steps or more are refused: split them into another run.
- A customer email becomes a proposal in your reply box, after your yes. In a mail thread (Gmail or any page), "draft for me: proposal (sends it to Verse)" on the tab card first asks you in the extension's own panel: "Verse wants to send this page", with the site and what goes. Only your Yes there reads the thread's text, at that moment, and sends it once to Verse's answer engine (`mode: 'proposal'`, `lib/proposal.js`; not kept there). The proposal card drafts from it and keeps the drafted proposal (yours to edit, copy or download), never the thread itself. On a site on your list, Verse then proposes "fill <the box you were in> with <the proposal as plain text>" as the same Yes / No card, with the same record. You still press send. Off the list, the proposal stays in its card.
- Which box: a reply or proposal Verse drafted for you goes into the very box you were typing in when you pointed Verse at the page, whatever its label says and in any language. If the mail app has re-drawn it since (Outlook does), Verse looks for the compose box by its shape: the multi-line box you type a message in, never the search box and never a one-line field like To or Subject. The box's label only breaks a tie. A step you typed yourself ("fill Reply with …") still finds its box by the label you gave.
- When the thread is a buyer's reply to a sale (the sender's domain is the one a sale job's stored reply came from), the same proposal also goes onto that job, as when the job is claimed: one `proposal.draft` record, one draft on the job, whichever way came first (owner only; `POST /api/queue` `op: 'draft-from-thread'`, `lib/job-draft.js`). A thread from anyone else attaches nothing.
- The page is read for Verse only after a Yes in the panel, never on the frame's say-so: the page in the frame can ask but can't answer the panel's card, so a page on a-to-mind.com gone wrong still can't read your tab. One card at a time (a second ask is refused), a click in its first moments doesn't count, and an unanswered card closes by itself after about two minutes.
- Every step leaves an execution record (`/api/actions`, kind `extension.act`, ref "site · label"), written as running before the step and ended done or failed after; a No is recorded as stubbed. The owner sees them in Verse's actions card ("my actions"). Without the owner's key there is no record, so there is no action.

Chrome's own pages, the Web Store and some PDFs can't be read; Verse says so. The old "Ask Verse about '…'" menu, which sent the selection as an ask, is gone (Adam, 2026-10-09).

**Reach.** Only `activeTab` and `scripting`: the extension gets into a tab only when you press the shortcut or use a menu there, only that tab, and only until it navigates. There is no access to every site. Acting on pages is B3 (above): one step at a time, a per-site allow list, and a yes before every change, three steps at most in a run.

**Who talks to whom.** The panel (`sidepanel.js`) is the only door between Verse and the extension. It takes messages only from the Verse frame at https://a-to-mind.com. Verse (`void.html`) takes them only from this extension's id, `dcjdpaeachfmfndklkiglgebfflamhkg`, which the `key` in `manifest.json` pins. The private half of that key was not kept: it's only needed to pack a .crx for the Web Store, and Verse stays off the store.

Also: the toolbar icon opens Verse in the side panel, and typing `void`, a space, then any ask in the address bar opens a-to-mind.com with that ask.

Install: `chrome://extensions` (or `edge://extensions`), switch on Developer mode, "Load unpacked", pick this folder (or unzip `void-extension.zip` first). An install from before 0.3.0 had a different id: remove it and load this one. Change the shortcut at `chrome://extensions/shortcuts`.

The panel frames https://a-to-mind.com. That only works because `void-live-deploy/_headers` allows `frame-ancestors chrome-extension:`; with the old `X-Frame-Options: DENY` the panel is blank.
Not listed on the Chrome Web Store, and it stays that way (Atom, 2026-09-28; Adam, 2026-10-09).
Tested by `node tools/test_extension.mjs`.
